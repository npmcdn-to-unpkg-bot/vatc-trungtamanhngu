// Agency Theme JavaScript

(function ($) {
    "use strict"; // Start of use strict

    // jQuery for page scrolling feature - requires jQuery Easing plugin
    $('a.page-scroll').bind('click', function (event) {
        var $anchor = $(this);
        $('html, body').stop().animate({
            scrollTop: ($($anchor.attr('href')).offset().top )
        }, 1250, 'easeInOutExpo');
        event.preventDefault();
    });

    // Highlight the top nav as scrolling occurs
    $('body').scrollspy({
        target: '.navbar-fixed-top',
        offset: 51
    });

    // Closes the Responsive Menu on Menu Item Click
    $('.navbar-collapse ul li a:not(.dropdown-toggle)').click(function () {
        $('.navbar-toggle:visible').click();
    });

    // Offset for Main Navigation
    $('#mainNav').affix({
        offset: {
            top: 100
        }
    })
    $('.carousel').carousel({
        interval: 5000 //changes the speed
    });
    $('select').select2();
    $("#slider1").revolution({
        sliderType: "standard",
        sliderLayout: "fullscreen",
        delay: 9000,
        onHoverStop: 'on',
        navigation: {
            onHoverStop: 'on',
            touch: {
                touchenabled: "on",
                swipe_treshold: 75,
                swipe_min_touches: 1,
                drag_block_vertical: false,
                swipe_direction: "horizontal"
            },
            arrows: {
                style: "",
                enable: true,
                rtl: false,
                hide_onmobile: false,
                hide_onleave: true,
                hide_delay: 200,
                hide_delay_mobile: 1200,
                hide_under: 0,
                hide_over: 9999,
                tmp: '',
                left: {
                    container: "slider",
                    h_align: "left",
                    v_align: "center",
                    h_offset: 20,
                    v_offset: 0
                },
                right: {
                    container: "slider",
                    h_align: "right",
                    v_align: "center",
                    h_offset: 20,
                    v_offset: 0
                }
            }
        }
    });
})(jQuery); // End of use strict
$(document).ready(function () {
    $("body").on("click", ".navbar-toggle", function () {
        $("#menu-mobile").toggleClass("is-visible");
    })
    $("body").on("click", "#menu-mobile ul li a", function () {
        var id = $(this).attr("data-rel");
        $("html, body").animate({scrollTop: $(id).offset().top}, 3000);
        $("#menu-mobile").removeClass("is-visible");
    })
});
